package com.jet.hotelreservation2.controller;


import com.jet.hotelreservation2.entity.Payment;
import com.jet.hotelreservation2.service.HotelService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/payments")
@RequiredArgsConstructor
public class PaymentController {
    private final HotelService hotelService;

    public static class PaymentRequest {
        public Long reservationId;
        public String method;
    }

    @PostMapping
    public Payment pay(@RequestBody PaymentRequest req) {
        return hotelService.processPayment(req.reservationId, req.method);
    }
}

