package com.jet.hotelreservation2.controller;


import com.jet.hotelreservation2.entity.Guest;
import com.jet.hotelreservation2.entity.Reservation;
import com.jet.hotelreservation2.service.HotelService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;

@RestController
@RequestMapping("/api/reservations")
@RequiredArgsConstructor
public class ReservationController {

    private final HotelService hotelService;

    public static class BookingRequest {
        public Long roomId;
        public String guestName;
        public String guestEmail;
        public String guestPhone;
        public String checkIn;
        public String checkOut;
    }

    @PostMapping
    public Reservation bookRoom(@RequestBody BookingRequest req) {
        LocalDate checkIn;
        LocalDate checkOut;
        try {
            checkIn = LocalDate.parse(req.checkIn);
            checkOut = LocalDate.parse(req.checkOut);
        } catch (DateTimeParseException e) {
            throw new RuntimeException("Tarix formatı yanlışdır. Düzgün format: YYYY-MM-DD");
        }

        Guest guest = new Guest(req.guestName, req.guestEmail, req.guestPhone);
        return hotelService.bookRoom(req.roomId, guest, checkIn, checkOut);
    }

    @GetMapping
    public List<Reservation> getAllReservations() {
        return hotelService.getAllReservations();
    }

    @DeleteMapping("/{id}")
    public String cancelReservation(@PathVariable Long id) {
        hotelService.cancelReservation(id);
        return "Bron ləğv edildi: " + id;
    }
}
