package com.jet.hotelreservation2.repository;

import com.jet.hotelreservation2.entity.Guest;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GuestRepository extends JpaRepository<Guest,Long> {
}
