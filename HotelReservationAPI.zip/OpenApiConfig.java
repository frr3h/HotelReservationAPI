package com.jet.hotelreservation2.config;


import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {
    @Bean
    public OpenAPI hotelReservationOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("Hotel Reservation API")
                        .description("Otaqların idarə olunması, rezervasiya və ödəniş əməliyyatları üçün REST API")
                        .version("v1.0")
                        .contact(new Contact().name("Hotel Reservation Team")));
    }

}
