package com.jet.hotelreservation2.entity;


import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

@Entity
@DiscriminatorValue("SUITE")
public class SuiteRoom extends Room{


    private static final double SURCHARGE = 50.0;
    private static final double SERVICE_FEE = 15.0;

    public SuiteRoom() {}
    public SuiteRoom(double basePricePerNight) { super(basePricePerNight); }

    @Override
    public double calculatePrice(int nights) {
        return (getBasePricePerNight() + SURCHARGE) * nights + SERVICE_FEE;
    }

    @Override
    public String getRoomType() { return "Suite"; }
}