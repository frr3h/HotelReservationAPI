package com.jet.hotelreservation2.service;

import com.jet.hotelreservation2.entity.Guest;
import com.jet.hotelreservation2.entity.Payment;
import com.jet.hotelreservation2.entity.Reservation;
import com.jet.hotelreservation2.entity.Room;
import com.jet.hotelreservation2.exception.ApiException;
import com.jet.hotelreservation2.repository.GuestRepository;
import com.jet.hotelreservation2.repository.PaymentRepository;
import com.jet.hotelreservation2.repository.ReservationRepository;
import com.jet.hotelreservation2.repository.RoomRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
@RequiredArgsConstructor
@CacheConfig(cacheNames = "availableRooms")
public class HotelService {
    private final RoomRepository roomRepository;
    private final GuestRepository guestRepository;
    private final ReservationRepository reservationRepository;
    private final PaymentRepository paymentRepository;

    @Cacheable
    public List<Room> getAvailableRooms() {
        return roomRepository.findByAvailableTrue();
    }

    @CacheEvict(allEntries = true)
    public Reservation bookRoom(Long roomId, Guest guest, LocalDate checkIn, LocalDate checkOut) {
        Room room = roomRepository.findById(roomId)
                .orElseThrow(() -> new ApiException("Otaq tapılmadı", HttpStatus.NOT_FOUND));

        if (!room.isAvailable()) {
            throw new ApiException("Otaq artıq doludur", HttpStatus.CONFLICT);
        }

        int nights = (int) ChronoUnit.DAYS.between(checkIn, checkOut);
        double totalPrice = room.calculatePrice(nights);

        Guest savedGuest = guestRepository.save(guest);
        Reservation reservation = new Reservation(savedGuest, room, checkIn, checkOut, totalPrice);

        room.setAvailable(false);
        roomRepository.save(room);

        return reservationRepository.save(reservation);
    }

    @CacheEvict(allEntries = true)
    public void cancelReservation(Long reservationId) {
        Reservation reservation = reservationRepository.findById(reservationId)
                .orElseThrow(() -> new ApiException("Bron tapılmadı", HttpStatus.NOT_FOUND));

        reservation.setStatus("CANCELLED");
        reservation.getRoom().setAvailable(true);

        roomRepository.save(reservation.getRoom());
        reservationRepository.save(reservation);
    }

    public List<Reservation> getAllReservations() {
        return reservationRepository.findAll();
    }

    public Payment processPayment(Long reservationId, String method) {
        Reservation reservation = reservationRepository.findById(reservationId)
                .orElseThrow(() -> new ApiException("Bron tapılmadı", HttpStatus.NOT_FOUND));

        Payment payment = new Payment(reservation, reservation.getTotalPrice(), method);
        payment.process();
        return paymentRepository.save(payment);
    }
}
