package com.jet.hotelreservation2.repository;

import com.jet.hotelreservation2.entity.Room;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RoomRepository extends JpaRepository<Room,Long> {
    List<Room> findByAvailableTrue();
}
