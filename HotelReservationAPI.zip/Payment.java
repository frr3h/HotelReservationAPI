package com.jet.hotelreservation2.entity;

import jakarta.persistence.*;

@Entity
public class Payment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne
    private Reservation reservation;

    private double amount;
    private String method; // CARD, CASH
    private String status; // SUCCESS, FAILED

    public Payment() {}

    public Payment(Reservation reservation, double amount, String method) {
        this.reservation = reservation;
        this.amount = amount;
        this.method = method;
    }

    // Ödəniş simulyasiyası - real bank inteqrasiyası yoxdur
    public void process() {
        this.status = Math.random() > 0.1 ? "SUCCESS" : "FAILED";
    }

    public Long getId() { return id; }
    public Reservation getReservation() { return reservation; }
    public double getAmount() { return amount; }
    public String getMethod() { return method; }
    public String getStatus() { return status; }
}
