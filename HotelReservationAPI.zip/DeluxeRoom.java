package com.jet.hotelreservation2.entity;


import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

@Entity
@DiscriminatorValue("DELUXE")
public class DeluxeRoom extends Room{

    private static final double SURCHARGE = 20.0;

    public DeluxeRoom() {}
    public DeluxeRoom(double basePricePerNight) { super(basePricePerNight); }

    @Override
    public double calculatePrice(int nights) {
        return (getBasePricePerNight() + SURCHARGE) * nights;
    }

    @Override
    public String getRoomType() { return "Deluxe"; }
}