package com.jet.hotelreservation2.controller;


import com.jet.hotelreservation2.entity.DeluxeRoom;
import com.jet.hotelreservation2.entity.Room;
import com.jet.hotelreservation2.entity.StandardRoom;
import com.jet.hotelreservation2.entity.SuiteRoom;
import com.jet.hotelreservation2.repository.RoomRepository;
import com.jet.hotelreservation2.service.HotelService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/rooms")
@RequiredArgsConstructor
public class RoomController {


    private final RoomRepository roomRepository;
    private final HotelService hotelService;

    public static class RoomRequest {
        public double basePricePerNight;
    }

    @GetMapping
    public List<Room> getAllRooms() {
        return roomRepository.findAll();
    }

    @GetMapping("/available")
    public List<Room> getAvailableRooms() {
        return hotelService.getAvailableRooms();
    }

    @PostMapping("/standard")
    public Room addStandardRoom(@RequestBody RoomRequest req) {
        StandardRoom r = new StandardRoom(req.basePricePerNight);
        return roomRepository.save(r);
    }

    @PostMapping("/deluxe")
    public Room addDeluxeRoom(@RequestBody RoomRequest req) {
        DeluxeRoom r = new DeluxeRoom(req.basePricePerNight);
        return roomRepository.save(r);
    }

    @PostMapping("/suite")
    public Room addSuiteRoom(@RequestBody RoomRequest req) {
        SuiteRoom r = new SuiteRoom(req.basePricePerNight);
        return roomRepository.save(r);
    }
}
