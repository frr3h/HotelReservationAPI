package com.jet.hotelreservation2.repository;

import com.jet.hotelreservation2.entity.Reservation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReservationRepository extends JpaRepository<Reservation,Long> {
}
