package com.jet.hotelreservation2.entity;

import jakarta.persistence.*;

import java.io.Serializable;

@Entity
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "room_type")
public abstract class Room implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private double basePricePerNight;
    private boolean available = true;

    public Room() {}

    public Room(double basePricePerNight) {
        this.basePricePerNight = basePricePerNight;
    }

    public abstract double calculatePrice(int nights);
    public abstract String getRoomType();

    public Long getId() { return id; }
    public double getBasePricePerNight() { return basePricePerNight; }
    public void setBasePricePerNight(double p) { this.basePricePerNight = p; }
    public boolean isAvailable() { return available; }
    public void setAvailable(boolean available) { this.available = available; }
}
