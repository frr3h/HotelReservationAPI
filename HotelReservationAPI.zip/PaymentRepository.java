package com.jet.hotelreservation2.repository;

import com.jet.hotelreservation2.entity.Payment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaymentRepository extends JpaRepository<Payment,Long> {
}
