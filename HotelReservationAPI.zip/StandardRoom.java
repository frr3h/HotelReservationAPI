package com.jet.hotelreservation2.entity;


import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

@Entity
@DiscriminatorValue("STANDARD")
public class StandardRoom extends Room {

    public StandardRoom() {}
    public StandardRoom(double basePricePerNight) { super(basePricePerNight); }

    @Override
    public double calculatePrice(int nights) {
        return getBasePricePerNight() * nights;
    }

    @Override
    public String getRoomType() { return "Standard"; }
}